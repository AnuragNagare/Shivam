import google.generativeai as genai
import json
from typing import Dict, List
import streamlit as st

class WorkflowAI:
    def __init__(self, api_key: str):
        # Configure Gemini with provided API key
        genai.configure(api_key=api_key)
        
        # Try different model versions
        self.model = self._initialize_model()
        
    def _initialize_model(self):
        """
        Initialize Gemini model with fallback options
        """
        model_options = [
            'gemini-1.5-flash',
            'gemini-1.5-pro',
            'gemini-pro',
            'gemini-1.0-pro'
        ]
        
        for model_name in model_options:
            try:
                model = genai.GenerativeModel(model_name)
                
                # Test the model with a simple prompt
                test_response = model.generate_content("Test")
                
                if test_response and test_response.text:
                    st.info(f"✅ Using model: {model_name}")
                    return model
                    
            except Exception as e:
                continue
        
        raise Exception("Could not initialize any Gemini model. Please check your API key.")
    
    def analyze_requirements(self, description: str, complexity: str, error_handling: bool) -> Dict:
        """
        Analyze user requirements and generate workflow structure
        """
        prompt = self._create_analysis_prompt(description, complexity, error_handling)
        
        try:
            response = self.model.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=0.7,
                    top_p=0.8,
                    top_k=40,
                    max_output_tokens=2048,
                )
            )
            
            if not response or not response.text:
                raise Exception("Empty response from Gemini API")
            
            # Parse the response
            workflow_structure = self._parse_ai_response(response.text)
            
            # Validate that we have nodes
            if not workflow_structure.get('nodes'):
                workflow_structure['nodes'] = self._create_default_nodes(description)
            
            return workflow_structure
            
        except Exception as e:
            error_msg = str(e)
            
            if "404" in error_msg or "not found" in error_msg:
                raise Exception(f"Model not available. Error: {error_msg}")
            elif "API_KEY" in error_msg:
                raise Exception("Invalid API key. Please check your API key.")
            elif "quota" in error_msg.lower():
                raise Exception("API quota exceeded. Please check your usage limits.")
            else:
                raise Exception(f"AI processing failed: {error_msg}")
    
    def _create_default_nodes(self, description: str) -> List[Dict]:
        """
        Create default nodes if AI doesn't generate any
        """
        default_nodes = [
            {
                "name": "Process Data",
                "type": "n8n-nodes-base.set",
                "description": "Process incoming data",
                "parameters": {
                    "assignments": {
                        "assignments": [
                            {
                                "name": "processed_data",
                                "value": "={{ $json }}",
                                "type": "string"
                            }
                        ]
                    }
                }
            }
        ]
        
        # Add email node if description mentions email
        if any(word in description.lower() for word in ['email', 'mail', 'send', 'notify']):
            default_nodes.append({
                "name": "Send Email",
                "type": "n8n-nodes-base.gmail",
                "description": "Send notification email",
                "parameters": {
                    "operation": "send",
                    "resource": "message",
                    "subject": "Workflow Notification",
                    "message": "Your workflow has been executed successfully!"
                }
            })
        
        return default_nodes
    
    def _create_analysis_prompt(self, description: str, complexity: str, error_handling: bool) -> str:
        """
        Create a structured prompt for Gemini
        """
        prompt = f"""
        You are an expert n8n workflow automation specialist. Analyze this user requirement and create a detailed workflow structure.

        User Description: "{description}"
        Complexity Level: {complexity}
        Include Error Handling: {error_handling}

        IMPORTANT: You must create at least 1-3 nodes for the workflow. Do not return empty nodes array.

        Please provide a JSON response with the following structure:
        {{
            "name": "workflow_name",
            "summary": "Brief description of what this workflow does",
            "trigger": {{
                "type": "webhook/schedule/email/manual",
                "description": "What triggers this workflow"
            }},
            "nodes": [
                {{
                    "name": "Node Name",
                    "type": "n8n-node-type",
                    "description": "What this node does",
                    "parameters": {{
                        "key": "value"
                    }}
                }}
            ],
            "connections": [
                {{
                    "from": "node1",
                    "to": "node2"
                }}
            ]
        }}

        Common n8n node types to use:
        - n8n-nodes-base.set (for data processing/transformation)
        - n8n-nodes-base.gmail (for email operations)
        - n8n-nodes-base.googleSheets (for spreadsheet operations)
        - n8n-nodes-base.slack (for messaging)
        - n8n-nodes-base.httpRequest (for API calls)
        - n8n-nodes-base.code (for custom logic)
        - n8n-nodes-base.if (for conditional logic)

        Example for "send email when form submitted":
        {{
            "name": "Form to Email Workflow",
            "summary": "Sends email notification when form is submitted",
            "trigger": {{
                "type": "webhook",
                "description": "Receives form submission data"
            }},
            "nodes": [
                {{
                    "name": "Process Form Data",
                    "type": "n8n-nodes-base.set",
                    "description": "Extract and format form data",
                    "parameters": {{
                        "assignments": {{
                            "assignments": [
                                {{
                                    "name": "user_email",
                                    "value": "={{{{ $json.email }}}}",
                                    "type": "string"
                                }}
                            ]
                        }}
                    }}
                }},
                {{
                    "name": "Send Confirmation Email",
                    "type": "n8n-nodes-base.gmail",
                    "description": "Send confirmation email to user",
                    "parameters": {{
                        "operation": "send",
                        "resource": "message",
                        "subject": "Form Submission Confirmation",
                        "message": "Thank you for your submission!"
                    }}
                }}
            ],
            "connections": [
                {{
                    "from": "Process Form Data",
                    "to": "Send Confirmation Email"
                }}
            ]
        }}

        Respond with ONLY the JSON structure, no additional text.
        """
        
        return prompt
    
    def _parse_ai_response(self, response_text: str) -> Dict:
        """
        Parse AI response and extract workflow structure
        """
        try:
            # Clean up the response
            response_text = response_text.strip()
            
            # Remove any markdown formatting
            if response_text.startswith('```json'):
                response_text = response_text[7:]
            if response_text.endswith('```'):
                response_text = response_text[:-3]
            
            # Remove any extra text before/after JSON
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx != -1:
                response_text = response_text[start_idx:end_idx]
            
            # Parse JSON
            workflow_structure = json.loads(response_text)
            
            # Validate structure
            required_keys = ['name', 'summary', 'trigger', 'nodes']
            for key in required_keys:
                if key not in workflow_structure:
                    raise ValueError(f"Missing required key: {key}")
            
            return workflow_structure
            
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse AI response as JSON: {str(e)}")
        except Exception as e:
            raise Exception(f"Error processing AI response: {str(e)}")