import streamlit as st
import json
import google.generativeai as genai
from ai_processor import WorkflowAI
from n8n_generator import N8nGenerator

# Page config
st.set_page_config(
    page_title="AI n8n Workflow Generator",
    page_icon="🤖",
    layout="wide"
)

# Initialize session state
if 'generated_workflow' not in st.session_state:
    st.session_state.generated_workflow = None
if 'ai_processor' not in st.session_state:
    st.session_state.ai_processor = None
if 'api_key_valid' not in st.session_state:
    st.session_state.api_key_valid = False
if 'template_text' not in st.session_state:
    st.session_state.template_text = ''

def validate_api_key(api_key: str) -> bool:
    """
    Validate Gemini API key by testing it
    """
    if not api_key or len(api_key) < 10:
        return False
    
    try:
        # Configure with the provided API key
        genai.configure(api_key=api_key)
        
        # Test with a simple model
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content("Hello, respond with 'OK'")
        
        if response and response.text and 'OK' in response.text:
            return True
        else:
            return False
            
    except Exception as e:
        st.error(f"API Key validation failed: {str(e)}")
        return False

def api_key_section():
    """
    Handle API key input and validation
    """
    st.header("🔑 API Key Configuration")
    
    # API key input
    api_key = st.text_input(
        "Enter your Gemini API Key:",
        type="password",
        placeholder="Enter your API key here...",
        help="Get your API key from https://makersuite.google.com/app/apikey"
    )
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        if st.button("🔍 Validate Key", type="primary"):
            if api_key:
                with st.spinner("Validating API key..."):
                    if validate_api_key(api_key):
                        st.session_state.api_key_valid = True
                        st.session_state.api_key = api_key
                        st.success("✅ API key is valid!")
                        st.rerun()
                    else:
                        st.session_state.api_key_valid = False
                        st.error("❌ Invalid API key!")
            else:
                st.warning("Please enter an API key first!")
    
    with col2:
        if st.session_state.api_key_valid:
            st.success("✅ API Key Status: Valid")
        else:
            st.error("❌ API Key Status: Not validated")
    
    # Instructions
    with st.expander("📋 How to get your Gemini API Key"):
        st.markdown("""
        1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
        2. Sign in with your Google account
        3. Click "Create API Key"
        4. Copy the generated API key
        5. Paste it in the field above and click "Validate Key"
        
        **Note:** Keep your API key secure and don't share it publicly!
        """)
    
    return st.session_state.api_key_valid

def initialize_ai(api_key: str):
    """Initialize AI processor with the provided API key"""
    if st.session_state.ai_processor is None:
        try:
            with st.spinner("🔄 Initializing AI model..."):
                st.session_state.ai_processor = WorkflowAI(api_key=api_key)
            return True
        except Exception as e:
            st.error(f"❌ Failed to initialize AI: {str(e)}")
            return False
    return True

def set_template(template_text):
    """Set template text in session state"""
    st.session_state.template_text = template_text

def main():
    st.title("🤖 AI-Powered n8n Workflow Generator")
    st.markdown("Describe your automation task in plain English, and I'll create an n8n workflow for you!")
    
    # API Key validation first
    if not api_key_section():
        st.warning("⚠️ Please enter and validate your API key to continue.")
        return
    
    # Main application
    st.markdown("---")
    
    # Sidebar for settings
    with st.sidebar:
        st.header("⚙️ Settings")
        complexity_level = st.selectbox(
            "Workflow Complexity",
            ["Simple", "Medium", "Complex"]
        )
        
        include_error_handling = st.checkbox("Include Error Handling", value=True)
        
        st.header("💡 Example Workflows")
        st.markdown("""
        - "Send email when form is submitted"
        - "Save Gmail attachments to Google Drive"
        - "Post to Slack when new customer signs up"
        - "Create calendar event from new Trello card"
        - "Backup database daily at 2 AM"
        """)
        
        # Quick templates
        st.header("🚀 Quick Templates")
        if st.button("📧 Email to Sheet"):
            set_template("When someone submits a contact form, save their name, email, and message to a Google Sheet and send them a confirmation email.")
        
        if st.button("💬 Slack Notification"):
            set_template("When a new order is placed, send a notification to the #orders Slack channel with customer details.")
        
        if st.button("📁 File Backup"):
            set_template("Every day at 2 AM, backup files from Google Drive to Dropbox.")
        
        # API status
        st.markdown("---")
        st.markdown("**🔑 API Status**")
        if st.session_state.api_key_valid:
            st.success("✅ Connected")
        else:
            st.error("❌ Not connected")
    
    # Main interface
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("📝 Describe Your Workflow")
        
        # Pre-fill from template if selected
        default_text = st.session_state.get('template_text', '')
        
        # Text input for workflow description
        user_description = st.text_area(
            "What do you want to automate?",
            value=default_text,
            height=200,
            placeholder="Example: When someone fills out my contact form, I want to save their details to a Google Sheet and send them a welcome email...",
            key="workflow_description"
        )
        
        # Clear template after using
        if default_text:
            st.session_state.template_text = ''
        
        # Generate button
        if st.button("🚀 Generate Workflow", type="primary"):
            if not user_description.strip():
                st.warning("Please describe your workflow first!")
                return
            
            # Initialize AI if not already done
            if not initialize_ai(st.session_state.api_key):
                return
            
            try:
                # Generate workflow structure
                workflow_structure = st.session_state.ai_processor.analyze_requirements(
                    user_description, 
                    complexity_level, 
                    include_error_handling
                )
                
                # Generate n8n JSON
                n8n_gen = N8nGenerator()
                workflow_json = n8n_gen.create_workflow(workflow_structure)
                
                # Store in session state
                st.session_state.generated_workflow = {
                    'description': user_description,
                    'structure': workflow_structure,
                    'json': workflow_json
                }
                
                st.success("✅ Workflow generated successfully!")
                
            except Exception as e:
                st.error(f"❌ Error generating workflow: {str(e)}")
                
                # Provide helpful suggestions
                if "API" in str(e) or "key" in str(e).lower():
                    st.info("💡 Try re-validating your API key")
                elif "model" in str(e).lower():
                    st.info("💡 Try refreshing the page and re-entering your API key")
                elif "quota" in str(e).lower():
                    st.info("💡 Check your API usage limits in Google AI Studio")
    
    with col2:
        st.header("⚙️ Generated Workflow")
        
        if st.session_state.generated_workflow:
            workflow_data = st.session_state.generated_workflow
            
            # Display workflow summary
            st.subheader("📋 Workflow Summary")
            st.info(workflow_data['structure'].get('summary', 'Workflow generated'))
            
            # Display trigger
            trigger_info = workflow_data['structure'].get('trigger', {})
            st.subheader("🔄 Trigger")
            st.write(f"**Type**: {trigger_info.get('type', 'Unknown')}")
            st.write(f"**Description**: {trigger_info.get('description', 'No description')}")
            
            # Display nodes
            st.subheader("🔗 Workflow Nodes")
            nodes = workflow_data['structure'].get('nodes', [])
            for i, node in enumerate(nodes):
                with st.expander(f"📦 {i+1}. {node['name']}", expanded=False):
                    st.write(f"**Type**: {node['type']}")
                    st.write(f"**Description**: {node.get('description', 'No description')}")
                    if node.get('parameters'):
                        st.write("**Parameters**:")
                        st.json(node['parameters'])
            
            # Workflow stats
            st.subheader("📊 Workflow Stats")
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                st.metric("Total Nodes", len(nodes))
            with col_b:
                st.metric("Connections", len(workflow_data['structure'].get('connections', [])))
            with col_c:
                st.metric("Complexity", complexity_level)
            
            # JSON download
            st.subheader("📥 Download n8n Workflow")
            json_str = json.dumps(workflow_data['json'], indent=2)
            
            col_download, col_copy = st.columns(2)
            
            with col_download:
                st.download_button(
                    label="📄 Download JSON",
                    data=json_str,
                    file_name=f"workflow_{workflow_data['structure'].get('name', 'generated').replace(' ', '_')}.json",
                    mime="application/json"
                )
            
            with col_copy:
                if st.button("📋 Copy JSON"):
                    st.text_area("JSON Code (Copy this):", json_str, height=100)
            
            # Import instructions
            with st.expander("📖 How to Import into n8n"):
                st.markdown("""
                1. **Download the JSON file** using the button above
                2. **Open your n8n instance** (cloud or self-hosted)
                3. **Click "Import from File"** in the workflows section
                4. **Select the downloaded JSON file**
                5. **Configure credentials** for the nodes that need authentication
                6. **Test the workflow** before activating
                7. **Activate the workflow** to start automation
                
                **Note**: You'll need to set up credentials for services like Gmail, Slack, etc.
                """)
            
            # Display JSON (collapsible)
            with st.expander("👁️ View JSON Code"):
                st.code(json_str, language='json')
                
        else:
            st.info("👈 Describe your workflow on the left to get started!")
            
            # Show sample workflow
            st.subheader("🎯 Sample Output")
            st.markdown("""
            After you generate a workflow, you'll see:
            - **Workflow Summary**: What the workflow does
            - **Trigger Information**: How the workflow starts
            - **Node Details**: Each step in the automation
            - **Downloadable JSON**: Ready to import into n8n
            """)

if __name__ == "__main__":
    main()