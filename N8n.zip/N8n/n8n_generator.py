import json
import uuid
from datetime import datetime
from typing import Dict, List

class N8nGenerator:
    def __init__(self):
        self.node_counter = 0
        
    def create_workflow(self, workflow_structure: Dict) -> Dict:
        """
        Convert workflow structure to n8n JSON format
        """
        # Reset counter for each workflow
        self.node_counter = 0
        
        workflow_json = {
            "name": workflow_structure.get('name', 'Generated Workflow'),
            "nodes": [],
            "connections": {},
            "active": False,
            "settings": {
                "executionOrder": "v1"
            },
            "id": str(uuid.uuid4()),
            "versionId": str(uuid.uuid4()),
            "meta": {
                "templateCredsSetupCompleted": True,
                "instanceId": str(uuid.uuid4())
            },
            "tags": []
        }
        
        # Generate nodes
        node_mapping = {}
        
        # Add trigger node first
        trigger_node = self._create_trigger_node(workflow_structure.get('trigger', {}))
        workflow_json['nodes'].append(trigger_node)
        node_mapping['trigger'] = trigger_node['name']
        
        # Add other nodes
        for node_data in workflow_structure.get('nodes', []):
            n8n_node = self._create_n8n_node(node_data)
            workflow_json['nodes'].append(n8n_node)
            node_mapping[node_data['name']] = n8n_node['name']
        
        # Generate connections
        connections = self._create_connections(workflow_structure, node_mapping)
        workflow_json['connections'] = connections
        
        # Add pinData (empty but required)
        workflow_json['pinData'] = {}
        
        return workflow_json
    
    def _create_trigger_node(self, trigger_data: Dict) -> Dict:
        """
        Create trigger node based on trigger type
        """
        self.node_counter += 1
        trigger_type = trigger_data.get('type', 'webhook').lower()
        
        if 'webhook' in trigger_type:
            return {
                "parameters": {
                    "httpMethod": "POST",
                    "path": "workflow-trigger",
                    "responseMode": "onReceived",
                    "options": {}
                },
                "name": "Webhook",
                "type": "n8n-nodes-base.webhook",
                "typeVersion": 1,
                "position": [240, 300],
                "id": str(uuid.uuid4()),
                "webhookId": str(uuid.uuid4())
            }
        elif 'schedule' in trigger_type or 'cron' in trigger_type:
            return {
                "parameters": {
                    "rule": {
                        "interval": [{
                            "field": "hours",
                            "hoursInterval": 1
                        }]
                    }
                },
                "name": "Schedule Trigger",
                "type": "n8n-nodes-base.scheduleTrigger",
                "typeVersion": 1,
                "position": [240, 300],
                "id": str(uuid.uuid4())
            }
        elif 'email' in trigger_type:
            return {
                "parameters": {
                    "pollTimes": {
                        "item": [{
                            "mode": "everyMinute"
                        }]
                    },
                    "format": "simple",
                    "options": {}
                },
                "name": "Email Trigger (IMAP)",
                "type": "n8n-nodes-base.emailReadImap",
                "typeVersion": 2,
                "position": [240, 300],
                "id": str(uuid.uuid4())
            }
        else:
            # Default to manual trigger
            return {
                "parameters": {},
                "name": "Manual Trigger",
                "type": "n8n-nodes-base.manualTrigger",
                "typeVersion": 1,
                "position": [240, 300],
                "id": str(uuid.uuid4())
            }
    
    def _create_n8n_node(self, node_data: Dict) -> Dict:
        """
        Create an n8n node from node data
        """
        self.node_counter += 1
        
        node_type = node_data.get('type', 'n8n-nodes-base.set')
        node_name = node_data.get('name', f'Node{self.node_counter}')
        
        # Clean node name (remove special characters)
        node_name = ''.join(c for c in node_name if c.isalnum() or c in (' ', '_', '-')).strip()
        if not node_name:
            node_name = f'Node{self.node_counter}'
        
        base_node = {
            "parameters": self._get_node_parameters(node_type, node_data.get('parameters', {})),
            "name": node_name,
            "type": node_type,
            "typeVersion": self._get_node_type_version(node_type),
            "position": [
                240 + (self.node_counter * 220),
                300
            ],
            "id": str(uuid.uuid4())
        }
        
        # Add node-specific configurations
        if node_type == "n8n-nodes-base.webhook":
            base_node["webhookId"] = str(uuid.uuid4())
        
        return base_node
    
    def _get_node_type_version(self, node_type: str) -> int:
        """
        Get the correct type version for different node types
        """
        type_versions = {
            "n8n-nodes-base.set": 3,
            "n8n-nodes-base.gmail": 2,
            "n8n-nodes-base.googleSheets": 4,
            "n8n-nodes-base.slack": 2,
            "n8n-nodes-base.httpRequest": 4,
            "n8n-nodes-base.code": 2,
            "n8n-nodes-base.if": 2,
            "n8n-nodes-base.webhook": 2,
            "n8n-nodes-base.scheduleTrigger": 1,
            "n8n-nodes-base.manualTrigger": 1,
            "n8n-nodes-base.emailReadImap": 2
        }
        
        return type_versions.get(node_type, 1)
    
    def _get_node_parameters(self, node_type: str, parameters: Dict) -> Dict:
        """
        Get default parameters for different node types
        """
        default_params = {
            "n8n-nodes-base.set": {
                "assignments": {
                    "assignments": [
                        {
                            "id": str(uuid.uuid4()),
                            "name": "message",
                            "value": "Workflow executed successfully",
                            "type": "string"
                        }
                    ]
                },
                "options": {}
            },
            "n8n-nodes-base.gmail": {
                "operation": "send",
                "resource": "message",
                "subject": "Workflow Notification",
                "message": "This is an automated message from your n8n workflow",
                "toEmail": "recipient@example.com",
                "options": {}
            },
            "n8n-nodes-base.googleSheets": {
                "operation": "append",
                "resource": "spreadsheet",
                "documentId": {
                    "__rl": True,
                    "mode": "id",
                    "value": "your-spreadsheet-id"
                },
                "sheetName": {
                    "__rl": True,
                    "mode": "name",
                    "value": "Sheet1"
                },
                "columns": {
                    "mappingMode": "defineBelow",
                    "value": {},
                    "matchingColumns": [],
                    "schema": []
                },
                "options": {}
            },
            "n8n-nodes-base.slack": {
                "operation": "postMessage",
                "resource": "message",
                "channel": "#general",
                "text": "Workflow notification from n8n",
                "otherOptions": {}
            },
            "n8n-nodes-base.httpRequest": {
                "method": "POST",
                "url": "https://api.example.com/webhook",
                "options": {},
                "bodyParameters": {
                    "parameters": []
                },
                "headerParameters": {
                    "parameters": []
                },
                "queryParameters": {
                    "parameters": []
                }
            },
            "n8n-nodes-base.code": {
                "mode": "runOnceForAllItems",
                "jsCode": "// Process your data here\nfor (const item of $input.all()) {\n  item.json.processed = true;\n}\n\nreturn $input.all();"
            },
            "n8n-nodes-base.if": {
                "conditions": {
                    "options": {
                        "caseSensitive": True,
                        "leftValue": "",
                        "typeValidation": "strict"
                    },
                    "conditions": [
                        {
                            "id": str(uuid.uuid4()),
                            "leftValue": "={{ $json.status }}",
                            "rightValue": "success",
                            "operator": {
                                "type": "string",
                                "operation": "equals"
                            }
                        }
                    ],
                    "combinator": "and"
                }
            }
        }
        
        # Get base parameters and merge with provided ones
        base_params = default_params.get(node_type, {}).copy()
        
        # Deep merge parameters
        for key, value in parameters.items():
            if isinstance(value, dict) and key in base_params and isinstance(base_params[key], dict):
                base_params[key].update(value)
            else:
                base_params[key] = value
        
        return base_params
    
    def _create_connections(self, workflow_structure: Dict, node_mapping: Dict) -> Dict:
        """
        Create connections between nodes
        """
        connections = {}
        
        # Get all nodes except trigger
        regular_nodes = workflow_structure.get('nodes', [])
        
        if not regular_nodes:
            return connections
        
        # Connect trigger to first node
        trigger_name = node_mapping.get('trigger', 'Webhook')
        first_node_name = node_mapping.get(regular_nodes[0]['name'])
        
        if first_node_name:
            connections[trigger_name] = {
                "main": [[{
                    "node": first_node_name,
                    "type": "main",
                    "index": 0
                }]]
            }
        
        # Create connections based on workflow structure
        explicit_connections = workflow_structure.get('connections', [])
        
        if explicit_connections:
            for connection in explicit_connections:
                from_node = node_mapping.get(connection['from'])
                to_node = node_mapping.get(connection['to'])
                
                if from_node and to_node:
                    if from_node not in connections:
                        connections[from_node] = {"main": [[]]}
                    
                    connections[from_node]["main"][0].append({
                        "node": to_node,
                        "type": "main",
                        "index": 0
                    })
        else:
            # Auto-connect nodes sequentially if no explicit connections
            for i in range(len(regular_nodes) - 1):
                current_node = node_mapping.get(regular_nodes[i]['name'])
                next_node = node_mapping.get(regular_nodes[i + 1]['name'])
                
                if current_node and next_node:
                    if current_node not in connections:
                        connections[current_node] = {"main": [[]]}
                    
                    connections[current_node]["main"][0].append({
                        "node": next_node,
                        "type": "main",
                        "index": 0
                    })
        
        return connections