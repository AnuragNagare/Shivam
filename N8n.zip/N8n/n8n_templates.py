class N8nTemplates:
    """Templates and structures for common n8n nodes"""
    
    def __init__(self):
        self.node_templates = {
            "webhook": {
                "parameters": {
                    "httpMethod": "POST",
                    "path": "webhook",
                    "responseMode": "onReceived"
                },
                "type": "n8n-nodes-base.webhook",
                "typeVersion": 1
            },
            "gmail": {
                "parameters": {
                    "operation": "send",
                    "resource": "message"
                },
                "type": "n8n-nodes-base.gmail",
                "typeVersion": 1
            },
            "slack": {
                "parameters": {
                    "operation": "postMessage",
                    "resource": "message"
                },
                "type": "n8n-nodes-base.slack",
                "typeVersion": 1
            },
            "googleSheets": {
                "parameters": {
                    "operation": "append",
                    "resource": "spreadsheet"
                },
                "type": "n8n-nodes-base.googleSheets",
                "typeVersion": 1
            }
        }
    
    def get_node_template(self, node_type):
        """Get template for specific node type"""
        return self.node_templates.get(node_type, {})