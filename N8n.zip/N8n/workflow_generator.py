import google.generativeai as genai
import json
import re
from n8n_templates import N8nTemplates

class WorkflowGenerator:
    def __init__(self):
        # Configure Gemini
        genai.configure(api_key="AIzaSyB6WFjSUaNtkwqRjqYNAbOQTKJTJHeh7bs")  # Replace with your key
        self.model = genai.GenerativeModel('gemini-pro')
        self.templates = N8nTemplates()
    
    def generate_workflow(self, description, complexity="Medium", error_handling=True):
        """Generate n8n workflow from natural language description"""
        
        # Create the prompt
        prompt = self._create_prompt(description, complexity, error_handling)
        
        # Call Gemini API
        response = self.model.generate_content(prompt)
        
        # Parse and validate the response
        workflow_json = self._parse_response(response.text)
        
        return workflow_json
    
    def _create_prompt(self, description, complexity, error_handling):
        """Create a detailed prompt for Gemini"""
        
        prompt = f"""
        You are an expert n8n workflow automation specialist. Create a complete n8n workflow JSON configuration based on the user's description.

        USER DESCRIPTION: {description}
        COMPLEXITY LEVEL: {complexity}
        INCLUDE ERROR HANDLING: {error_handling}

        REQUIREMENTS:
        1. Generate a valid n8n workflow JSON structure
        2. Include all necessary nodes with proper configuration
        3. Connect nodes with proper connections array
        4. Use realistic node IDs and names
        5. Include proper positioning coordinates
        6. Add error handling nodes if requested

        AVAILABLE N8N NODES (use appropriate ones):
        - Webhook (trigger)
        - Email Trigger
        - Schedule Trigger
        - HTTP Request
        - Gmail
        - Slack
        - Google Sheets
        - Set (for data transformation)
        - IF (for conditional logic)
        - Code (for custom logic)
        - Email Send
        - Stop and Error (for error handling)

        WORKFLOW JSON STRUCTURE:
        {{
          "name": "Generated Workflow Name",
          "nodes": [
            {{
              "parameters": {{}},
              "id": "unique-id",
              "name": "Node Name",
              "type": "NodeType",
              "typeVersion": 1,
              "position": [x, y]
            }}
          ],
          "connections": {{
            "Node Name": {{
              "main": [[{{"node": "Next Node Name", "type": "main", "index": 0}}]]
            }}
          }}
        }}

        Return ONLY the JSON configuration, no additional text or explanation.
        """
        
        return prompt
    
    def _parse_response(self, response_text):
        """Parse and validate the Gemini response"""
        
        # Try to extract JSON from response
        try:
            # Remove any markdown formatting
            json_text = response_text.strip()
            if json_text.startswith('```json'):
                json_text = json_text[7:-3]
            elif json_text.startswith('```'):
                json_text = json_text[3:-3]
            
            # Parse JSON
            workflow_json = json.loads(json_text)
            
            # Basic validation
            if not isinstance(workflow_json, dict):
                raise ValueError("Response is not a valid JSON object")
            
            if 'nodes' not in workflow_json:
                raise ValueError("Workflow must contain 'nodes' array")
            
            return workflow_json
            
        except json.JSONDecodeError as e:
            # If JSON parsing fails, return a basic structure
            return {
                "name": "Generated Workflow",
                "nodes": [
                    {
                        "parameters": {},
                        "id": "webhook-trigger",
                        "name": "Webhook",
                        "type": "n8n-nodes-base.webhook",
                        "typeVersion": 1,
                        "position": [250, 300]
                    }
                ],
                "connections": {},
                "error": f"Could not parse AI response: {str(e)}"
            }
        
        except Exception as e:
            return {
                "name": "Error",
                "nodes": [],
                "connections": {},
                "error": f"Generation failed: {str(e)}"
            }