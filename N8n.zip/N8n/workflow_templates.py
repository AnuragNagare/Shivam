"""
Common workflow templates for quick generation
"""

def get_email_to_sheet_template():
    return {
        "name": "Email to Google Sheets",
        "summary": "Save email data to Google Sheets",
        "trigger": {
            "type": "webhook",
            "description": "Receives form submission via webhook"
        },
        "nodes": [
            {
                "name": "Process Data",
                "type": "n8n-nodes-base.set",
                "description": "Process incoming data"
            },
            {
                "name": "Save to Sheet",
                "type": "n8n-nodes-base.googleSheets",
                "description": "Save data to Google Sheets"
            },
            {
                "name": "Send Email",
                "type": "n8n-nodes-base.gmail",
                "description": "Send confirmation email"
            }
        ],
        "connections": [
            {"from": "Process Data", "to": "Save to Sheet"},
            {"from": "Save to Sheet", "to": "Send Email"}
        ]
    }

def get_slack_notification_template():
    return {
        "name": "Slack Notification",
        "summary": "Send notification to Slack",
        "trigger": {
            "type": "webhook",
            "description": "Receives notification trigger"
        },
        "nodes": [
            {
                "name": "Format Message",
                "type": "n8n-nodes-base.set",
                "description": "Format the message for Slack"
            },
            {
                "name": "Send to Slack",
                "type": "n8n-nodes-base.slack",
                "description": "Send message to Slack channel"
            }
        ],
        "connections": [
            {"from": "Format Message", "to": "Send to Slack"}
        ]
    }

COMMON_TEMPLATES = {
    "email_to_sheet": get_email_to_sheet_template,
    "slack_notification": get_slack_notification_template
}